# 🧮 Aplikasi Latihan Matematika

Aplikasi latihan matematika interaktif dengan soal acak untuk:
- Penjumlahan
- Pengurangan
- Perkalian
- Pembagian

## 🚀 Cara Menjalankan

```bash
pip install -r requirements.txt
streamlit run latihan_matematika.py
